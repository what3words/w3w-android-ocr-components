=== what3words w3w-data Release Notes ===

Release Notes:
==============

# Version 53.10.0:

Changes:
* Added Khmer and Lao as live languages.
* Updated nearest place data.

# Version 51.10.0:

Changes:
* Updated Japanese to include oceans.
* Added Catalan as live language.
* Updated nearest place data.

# Version 50.10.0:

Changes:
* Updated data format version to 10.
* Updated Vietnamese wordlist to include spaces.

# Version 50.9.0:

Changes:
* Updated Bengali and Marathi wordlists.
* Added new territory information.
* Updated vocon build to allow for extra/corrected pronounciations.
* Updated data format version to 9.

# Version 50.8.0:

Changes:
* Added Farsi and Odia as live languages. 

# Version 48.8.1:

Changes:
* Updated OCR versions for German, English, Spanish, Portugeuse and Russian.

# Version 48.8.0:

Changes:
* Added Amharic as a live language.

# Version 47.8.0:

Changes:
* Updated data format version to 8.
* Updated nearest place data.

# Version 47.7.0:

Changes:
* Added Slovak as a live language.

# Version 46.7.0:

Changes:
* Added Ukrainian as a live language.

# Version 45.7.2:

Changes:
* Updated countries data.
* Updated normalisation table.

# Version 45.7.1:

Changes:
* Remove Beta from Viatnamese.

# Version 45.7.0:

Changes:
* Added Viatnamese as a live language.
* Added Hindi VoCon support.
* Use tesseract 4 artifacts for OCR. 

# Version 44.7.0:

Changes:
* Added Welsh as a live language. 

# Version 43.7.1:

Changes:
* Don't add secondaries to VoCon grammers.

# Version 43.7.0:

Changes:
* Update nearest place data.
* Added Gujarati, Nepali and Panjabi as live languages.
* Updated normalisation table.

# Version 40.7.1:

Changes:
* Remove Beta from Kannada, Urdu and Malayalam. 

# Version 40.7.0:

Changes:
* Updated Kannada and Malayalam as live languages. 
* Add Urdu as live language

# Version 39.7.0:

Changes:
* Added Kannada and Malayalam as live languages.